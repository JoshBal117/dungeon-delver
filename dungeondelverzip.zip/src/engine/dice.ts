import { rng } from "./rng";
export function d4(): number { return rng.int(1, 4); }


