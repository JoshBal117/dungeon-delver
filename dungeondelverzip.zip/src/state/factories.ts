import type { Actor } from '../engine/types';
import { xpToNextLevel } from '../engine/leveling';
import { computeHpMax, computeMpMax } from '../engine/derived';


export function makeKnight(): Actor {
  const a: Actor = {
    id: 'hero',
    name: 'Knight',
    isPlayer: true,
    level: 1,
    xp: 0,
    xpToNext: xpToNextLevel(1),
    tags: { spellcaster: false },
    base: {
      str: 4, dex: 3, int: 1, wis: 2, vit: 3,
      speed: 4, armor: 3, resist: 0, luck: 2,
    },
    gear: { hpMax: 0, mpMax: 0, speed: 0, armorPct: 0, resistPct: 0 },
    hp: { current: 0, max: 0 },
    mp: { current: 0,  max: 0  },
  };

  const hpMax = computeHpMax(a);
  const mpMax = computeMpMax(a);
  a.hp = {current: hpMax, max: hpMax};
  a.mp = {current: mpMax, max: mpMax};
  return a;

}

export function makeGoblin( id=1): Actor {
  const a: Actor = {
    id: `gob-${id}`,
    name: 'Goblin',
    isPlayer: false,
    level: 1,
    xp: 0,
    xpToNext: xpToNextLevel(1),
    tags: { spellcaster: false },
    base: {
      str: 3, dex: 4, int: 1, wis: 1, vit: 2,
      speed: 3, armor: 0, resist: 0, luck: 2,
    },
    gear: { hpMax: 0, mpMax: 0, speed: 0, armorPct: 0, resistPct: 0 },
    hp: { current: 8, max: 8 },
    mp: { current: 0, max: 0 },
  };

  const hpMax = computeHpMax(a);
  const mpMax = computeMpMax(a);
  a.hp = {current: hpMax, max: hpMax};
  a.mp = {current: mpMax, max: mpMax};
  return a;
}
